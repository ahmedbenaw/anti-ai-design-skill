#!/usr/bin/env python3
"""Before the session ends, check the UI files it actually touched.

Why this is a separate hook: the per-file hook sees one file at a time and
speaks only when that file is bad. Neither of those catches the failure this
skill exists to prevent, which is presenting work that was never scanned at
all. Four of four pages generated with an earlier version of this skill were
presented having passed one guard and failed another.

It finds the files from the session transcript rather than from a marker file
it wrote earlier. A marker is state that goes stale, gets deleted, or survives
into the next session and reports on work that is already finished. The
transcript is what actually happened.

It nags once, and only about things an edit can fix.

Exit 2 on a Stop event stops the session ending and hands the text back to
Claude, so this is a blocking hook whether or not that was intended. Two
guards keep it from becoming a trap. It returns immediately when
stop_hook_active is set, which is the field that exists to break exactly this
loop, so the reminder happens once rather than forever. And when the only
thing wrong is that the brand guard is not installed, it reports on stdout and
does not block at all - no amount of editing fixes a missing checker, so
holding the session hostage over it would be cruel and pointless.

Reads the hook payload on stdin. Exit 0 with nothing to say, or 2 with the
reminder on stderr.
"""

import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# Bounded so that a long session cannot turn the end of a turn into a scan of
# every file it ever mentioned.
MAX_FILES = 12


# Recorded evidence is not work in progress. An eval baseline is *supposed* to
# fail: that failure is the measurement. Editing it to clear this hook would
# falsify the record, which is the one thing this skill must never do. So these
# paths are skipped, and the hook says which ones, because a silent skip is how
# a guard quietly stops guarding.
EVIDENCE_DIR = re.compile(r"(?:^|/)[\w.-]*-workspace/")
EVIDENCE_FIXTURE = re.compile(r"(?:^|/)anti-ai-design-style/examples/")


def skipped_note(evidence):
    if not evidence:
        return ""
    return ("\nSkipped as recorded evidence (measurements, not work): "
            + ", ".join(os.path.basename(e) for e in evidence[:6]))


def is_recorded_evidence(path):
    """True for measurements and fixtures that exist to be looked at, not fixed.

    Two shapes. Eval workspaces hold recorded measurements; a baseline that
    fails is the result, and editing it would falsify the record. The skill's
    own examples/ folder holds fixtures; slop-example.html fails on purpose.
    The match is on the skill's own folder name, so a user's file that merely
    shares the name examples/slop-example.html is still checked.

    The first version kept the slop fixture checked because the selftest used
    it to prove the hook speaks up. The selftest now proves that on a copy at
    a neutral path, so the rule and its proof both survive.
    """
    norm = path.replace(os.sep, "/")
    return bool(EVIDENCE_DIR.search(norm) or EVIDENCE_FIXTURE.search(norm))


def ui_files_from(transcript_path):
    """Every existing UI file path the transcript mentions, newest first.

    Deliberately loose. This is a reminder, and a path that appears in the
    transcript but was only read rather than written costs one extra file in
    a scan. Missing a file that was written costs the thing the hook is for.
    """
    try:
        with open(transcript_path, encoding="utf-8", errors="replace") as f:
            body = f.read()
    except OSError:
        return []
    pattern = r'["\']([^"\']+?\.(?:html|htm|css|scss|jsx|tsx|vue|svelte|astro))["\']'
    seen, out = set(), []
    for match in reversed(re.findall(pattern, body)):
        if match in seen:
            continue
        seen.add(match)
        if os.path.isfile(match):
            out.append(match)
        if len(out) >= MAX_FILES:
            break
    return out


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0

    # Set on the second and later passes, when the session is already being
    # continued because of a stop hook. Without this check the hook fires
    # again on the retry, and again, and the session cannot end.
    if payload.get("stop_hook_active"):
        return 0

    transcript = payload.get("transcript_path")
    if not transcript:
        return 0
    files = ui_files_from(transcript)
    evidence = [f for f in files if is_recorded_evidence(f)]
    files = [f for f in files if not is_recorded_evidence(f)]
    if not files:
        return 0                      # no UI work this session; stay quiet

    try:
        out = subprocess.run(
            [sys.executable, os.path.join(HERE, "verify_all.py"),
             "--json"] + files,
            capture_output=True, text=True, timeout=120)
    except Exception:
        return 0

    line = out.stdout.strip().splitlines()[-1] if out.stdout.strip() else ""
    if out.returncode == 0:
        return 0                      # everything passed; nothing to say

    checked = ", ".join(os.path.basename(f) for f in files)

    # Work out whether anything here is actually fixable. If the design is
    # clean and the only failure is a checker that is not installed, saying
    # "fix what the line names" is nonsense and blocking on it is worse.
    # verify_all --json prints the JSON object and then the proof line, so
    # the stream is not a single JSON document. raw_decode reads the object
    # and stops where it ends, instead of choking on the trailing line.
    summary = {}
    text = out.stdout.lstrip()
    if text.startswith("{"):
        try:
            summary, _ = json.JSONDecoder().raw_decode(text)
        except ValueError:
            summary = {}
    # "NOT RUN" means not installed; "DID NOT RUN" means installed and it
    # failed to produce a verdict. Only the first deserves install advice.
    # "NOT RUN" cannot happen any more: the brand check ships in this skill.
    # A crash still can, and it needs a different sentence.
    brand_missing = "brand distance NOT RUN" in line
    brand_crashed = "DID NOT RUN" in line
    others_ok = all(
        summary.get(k, {}).get("ok", False) for k in ("scan", "copy")) \
        if summary else False

    if brand_missing and others_ok:
        print("The design guards passed, but brand distance never ran. That "
              "check ships inside\nthis skill, so this is a fault to report, "
              "not something to install.\n\n  " + line +
              "\n\nFiles checked: " + checked)
        return 0                      # informative, not a blocker

    sys.stderr.write(
        "This session changed UI files, and they do not pass the design "
        "guards yet.\n\n"
        "  " + line + "\n\n"
        "Files checked: " + checked + skipped_note(evidence) + "\n\n" +
        ("The brand check did not return a verdict. Run "
         "scripts/brand_distance.py by hand\non the same files to see its "
         "error; no edit to the page can fix it.\n\n"
         if (brand_missing or brand_crashed) else "") +
        "Fix what the line names, then run verify_all.py again. Do not "
        "present unscanned\nvisual output: everything AI makes looks fine, so "
        "\"it looks fine\" is not a check.\n")
    return 2


EVIDENCE_CASES = [
    # (path, should_be_skipped, why)
    ("proj/anti-ai-design-style-workspace/iteration-2/x/with_skill/outputs/page.html", True,
     "an eval output is a recorded measurement"),
    ("proj/my-skill-workspace/iteration-1/review.html", True,
     "the eval viewer is generated, not authored"),
    ("proj/src/pages/index.html", False, "ordinary work is not evidence"),
    ("proj/workspace-notes/index.html", False,
     "a folder merely containing the word workspace is not an evidence archive"),
    ("proj/anti-ai-design-style/examples/slop-example.html", True,
     "the skill's own bad example exists to fail; the selftest proves the hook on a copy"),
    ("proj/anti-ai-design-style/examples/fixed-example.html", True,
     "the skill's own good example is a fixture too"),
    ("proj/site/examples/slop-example.html", False,
     "a user's own file with the same name is real work"),
]


def selftest():
    """Both directions, driven through real transcript files."""
    for path, want_skip, why in EVIDENCE_CASES:
        got = is_recorded_evidence(path)
        print("  {} {}: {}".format("ok  " if got == want_skip else "FAIL", why, path))
        ok_ev = got == want_skip
        if not ok_ev:
            globals()["_EVIDENCE_FAILED"] = True
    import tempfile
    import shutil
    here = os.path.dirname(HERE)
    # The skill's own examples are skipped as fixtures, so the proof that the
    # hook speaks up runs on copies at neutral paths. The rule and its proof
    # both survive that way.
    scratch = tempfile.mkdtemp(prefix="stop-check-")
    slop = os.path.join(scratch, "bad-page.html")
    fixed = os.path.join(scratch, "good-page.html")
    shutil.copy(os.path.join(here, "examples", "slop-example.html"), slop)
    shutil.copy(os.path.join(here, "examples", "fixed-example.html"), fixed)
    cases = [
        ("speaks up when a touched page fails", slop, 2),
        ("stays silent when the page passes", fixed, 0),
        ("stays silent when no UI file was touched", None, 0),
    ]
    ok = True
    # The loop guard, and the case that would otherwise trap a user.
    out = subprocess.run(
        [sys.executable, os.path.abspath(__file__)],
        input=json.dumps({"hook_event_name": "Stop", "stop_hook_active": True,
                          "transcript_path": "/nonexistent"}),
        capture_output=True, text=True)
    good = out.returncode == 0
    ok = ok and good
    print("  {} stop_hook_active means nag once, never loop".format(
        "ok  " if good else "FAIL"))

    t = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False)
    t.write(json.dumps({"file_path": fixed}) + "\n")
    t.close()
    env = dict(os.environ, HOME=tempfile.mkdtemp())
    env.pop("ANTI_ANTROPIK_PATH", None)
    # No installed sibling on this fake HOME, so there is no cross-check. The
    # brand verdict must still be produced, by this skill's own checker.
    env["ANTI_ANTROPIK_NO_VENDORED"] = "1"
    out = subprocess.run(
        [sys.executable, os.path.abspath(__file__)],
        input=json.dumps({"hook_event_name": "Stop", "transcript_path": t.name}),
        capture_output=True, text=True, env=env)
    good = out.returncode == 0
    ok = ok and good
    print("  {} a clean page with no installed sibling still passes and does "
          "not block".format("ok  " if good else "FAIL"))

    for label, path, want in cases:
        t = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False)
        t.write(json.dumps({"tool": "Write",
                            "file_path": path or "scripts/etl.py"}) + "\n")
        t.close()
        out = subprocess.run(
            [sys.executable, os.path.abspath(__file__)],
            input=json.dumps({"hook_event_name": "Stop",
                              "transcript_path": t.name}),
            capture_output=True, text=True)
        good = out.returncode == want and not (want == 0 and out.stderr.strip())
        ok = ok and good
        print("  {} {} (exit {})".format("ok  " if good else "FAIL", label,
                                         out.returncode))
    out = subprocess.run([sys.executable, os.path.abspath(__file__)],
                         input="not json", capture_output=True, text=True)
    good = out.returncode == 0
    ok = ok and good
    print("  {} survives junk input".format("ok  " if good else "FAIL"))
    print("SELFTEST: {}".format("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    sys.exit(main())
